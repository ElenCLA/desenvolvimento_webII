<?php
echo "Olá, mundo!";