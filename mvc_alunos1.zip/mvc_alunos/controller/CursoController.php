<?php

include_once(__DIR__ . "/../dao/CursoDAO.php");

class CursoController {

    private CursoDAO $curso_DAO;

    public function __construct()
    {
        $this->curso_DAO = new CursoDAO();
    }

    public function listar() {
        return $this->curso_DAO->listar();
    }
}