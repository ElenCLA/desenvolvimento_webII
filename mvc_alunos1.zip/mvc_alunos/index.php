<?php
    //Redireciona para a listagem de alunos
    header("location: ./view/alunos/listar.php");

    ///var/www/html/mvc_alunos/index.php
    //http://localhost/mvc_alunos/view/alunos/listar.php